#include<iostream>
#include "Sudo.h"

using namespace std;

int main()
{
    sudoku s;
    s.printSudokuGrid();
    s.initializeSudokuGrid();
    s.printSudokuGrid();
    std::cout << "\n after solving the problem \n";
    if (s.solveSudoku())
        s.printSudokuGrid();
    else
        std::cout << "\n solution doesnt exist for this type of solution \n";
    return 0;
}
